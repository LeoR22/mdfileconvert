from setuptools import setup, find_packages

setup(
    name="mdfileconvert",
    version="2.0.0",
    packages=find_packages(),
)
