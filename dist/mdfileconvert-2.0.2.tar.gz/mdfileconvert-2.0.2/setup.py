from setuptools import setup, find_packages

setup(
    name="mdfileconvert",
    version="2.0.2",
    packages=find_packages(),
)
